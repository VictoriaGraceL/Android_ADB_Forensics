# Android ADB Forensics Lab

A Digital Forensics bonus assignment by **Viktoriia Lavrenchuk**, completed October 25, 2026.

This project documents setting up Ubuntu in VMware, connecting a Samsung Android phone through USB debugging, and collecting device information with Android Debug Bridge (ADB). It includes successful command results and the installation and troubleshooting record.

## Lab environment

| Component | Configuration |
| --- | --- |
| Phone | Samsung Galaxy A13 5G, SM-A136U |
| Phone software | Android 13, One UI Core 5.1 |
| Host | Windows |
| Guest | Ubuntu 64 bit in VMware Workstation |
| Virtual disk | 30 GB, split into multiple files |
| RAM | 4096 MB |
| CPU | 2 cores |
| Networking | NAT |
| Phone connection | USB passthrough to Ubuntu, with USB debugging authorized |

## Results

The final `adb devices` output shows the phone with status `device`. Subsequent commands returned device properties, installed package information, usage statistics, battery statistics, and system settings.

| Assignment evidence | Command | Screenshot |
| --- | --- | --- |
| Connected phone | `adb devices` | [Figure 1](screenshots/01-authorized-phone-connection.jpg) |
| Device properties | `adb shell getprop` | [Figure 2](screenshots/02-android-device-properties.jpg) |
| Installed apps | `adb shell pm list packages -f` | [Figure 3](screenshots/03-installed-application-packages.jpg) |
| Usage statistics | `adb shell dumpsys usagestats` | [Figure 4](screenshots/04-system-usage-statistics.jpg) |
| Battery statistics | `adb shell dumpsys batterystats` | [Figure 5](screenshots/05-battery-statistics.jpg) |
| System settings | `adb shell settings list system` | [Figure 6](screenshots/06-system-settings.jpg) |

Some screenshots capture the end of long output and the returned prompt, rather than the command line. System settings describe configuration; they are not browser history. Battery measured charge statistics were reported as unsupported for this device.

## Repository contents

- [Word report](docs/Android_ADB_Forensics_Report.docx): report with all 33 images and explanatory captions.
- [Setup and collection instructions](docs/SETUP.md): steps used to prepare the lab.
- [Troubleshooting](docs/TROUBLESHOOTING.md): observed issues and their resolution.
- [Screenshot index](screenshots/README.md): all 33 images with descriptions.
- [ADB commands](commands/adb-commands.txt): reference commands, run individually.

## Scope

This lab used authorized USB debugging on my phone. It did not perform a full physical acquisition, root the phone, or recover deleted data or private app databases. The repository contains screenshots and the report; it does not contain full exported text dumps.

## Before publishing

The original evidence images and embedded report images contain phone identifiers, including a phone number, serial number, and IMEI. Review and redact these details in both the screenshots and the Word report before publishing a public repository.

## Assignment resources

- [AndroidForensics tutorial](https://github.com/DouglasFreshHabian/AndroidForensics)
- [Associated video](https://www.youtube.com/watch?v=hICezC7mI68)

## Uploading to GitHub

Extract this ZIP, open the `android-adb-forensics-lab` folder, and upload its contents to your repository. Keep the folder structure intact so the screenshot and document links work. GitHub displays this README automatically. No credentials or GitHub tokens are required in these files.
